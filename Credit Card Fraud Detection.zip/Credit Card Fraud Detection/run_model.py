import pandas as pd
import numpy as np
import joblib

# Load dataset
print("Loading dataset...")
credit_card_data = pd.read_csv("data/creditcard.csv")

# Load trained model
print("Loading fraud detection model...")
model = joblib.load("models/fraud_model.pkl")

# Check dataset shape
print(f"Dataset Shape: {credit_card_data.shape}")

# Drop 'Class' column and ensure 30 features for prediction
df_features = credit_card_data.drop(columns=["Class"])  
print(f"Features Shape: {df_features.shape}")

# Convert to DataFrame (Fix for feature names warning)
X = pd.DataFrame(df_features, columns=df_features.columns)

# Predict fraud cases
print("Making predictions...")
credit_card_data["Fraud Prediction"] = model.predict(X)

# Save predictions
credit_card_data.to_csv("predictions.csv", index=False)
print("✅ Predictions saved to 'predictions.csv'!")
