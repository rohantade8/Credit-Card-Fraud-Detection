import streamlit as st
import pandas as pd
import joblib

# Load the trained model
model = joblib.load(r"C:\Users\Acer\Desktop\TCS project\Credit Card Fraud Detection\models\fraud_model.pkl", mmap_mode=None)

# Streamlit UI
st.title("💳 Credit Card Fraud Detection")
st.write("Upload a CSV file to check for fraudulent transactions.")

# File uploader
uploaded_file = st.file_uploader("Upload CSV", type=["csv"])

if uploaded_file is not None:
    # Load the dataset
    df = pd.read_csv(uploaded_file)

    # Ensure the dataset has the required features
    required_features = model.feature_names_in_
    if not all(feature in df.columns for feature in required_features):
        st.error("Uploaded CSV does not have the required features for prediction!")
    else:
        # Select only required columns
        X = df[required_features]

        # Make predictions
        df["Fraud Prediction"] = model.predict(X)

        # Display results
        st.write("### Prediction Results")
        st.write(df[["Fraud Prediction"]].value_counts())

        # Download button for predictions
        st.download_button("Download Predictions", df.to_csv(index=False), "predictions.csv", "text/csv")

