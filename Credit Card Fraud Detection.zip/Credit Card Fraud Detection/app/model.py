import joblib
import numpy as np
import os

# Define model path
model_path = r"C:\Users\Acer\Desktop\TCS project\Credit Card Fraud Detection\models\fraud_model.pkl"

# Load the trained model safely
if not os.path.exists(model_path):
    raise FileNotFoundError(f"Model file not found: {model_path}")

model = joblib.load(model_path)

# Define the function to make predictions
def predict_fraud(features):
    try:
        features = np.array(features).reshape(1, -1)  # Ensure input shape is correct

        if features.shape[1] != model.n_features_in_:
            return f"Error: Expected {model.n_features_in_} features, but received {features.shape[1]}"

        prediction = model.predict(features)[0]
        return prediction

    except Exception as e:
        return f"Prediction error: {e}"

# Example Usage
# print(predict_fraud([feature1, feature2, ...]))
